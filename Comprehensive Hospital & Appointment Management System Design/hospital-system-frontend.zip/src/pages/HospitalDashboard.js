import React from 'react';

function HospitalDashboard() {
  return (
    <div>
      <h2>Hospital Admin Dashboard</h2>
      <ul>
        <li>List of doctors</li>
        <li>Total consultations</li>
        <li>Revenue summary (per doctor, per department)</li>
      </ul>
    </div>
  );
}

export default HospitalDashboard;
