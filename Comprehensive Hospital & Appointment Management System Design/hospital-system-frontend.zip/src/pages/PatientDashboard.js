import React from 'react';

function PatientDashboard() {
  return (
    <div>
      <h2>Patient Dashboard</h2>
      <ul>
        <li>Consultation history</li>
        <li>Doctors visited</li>
        <li>Hospitals visited</li>
      </ul>
    </div>
  );
}

export default PatientDashboard;
