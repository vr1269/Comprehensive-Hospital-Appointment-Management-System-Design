import React from 'react';
import { Link } from 'react-router-dom';

function Home() {
  return (
    <div>
      <h1>Welcome to Hospital Management System</h1>
      <nav>
        <Link to="/register-hospital">Register Hospital</Link><br/>
        <Link to="/register-doctor">Register Doctor</Link><br/>
        <Link to="/register-patient">Register Patient</Link><br/>
        <Link to="/hospital-dashboard">Hospital Dashboard</Link><br/>
        <Link to="/doctor-dashboard">Doctor Dashboard</Link><br/>
        <Link to="/patient-dashboard">Patient Dashboard</Link>
      </nav>
    </div>
  );
}

export default Home;
