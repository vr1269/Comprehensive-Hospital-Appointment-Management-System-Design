import React from 'react';

function DoctorDashboard() {
  return (
    <div>
      <h2>Doctor Dashboard</h2>
      <ul>
        <li>Total consultations</li>
        <li>Total earnings</li>
        <li>Earnings per hospital</li>
      </ul>
    </div>
  );
}

export default DoctorDashboard;
