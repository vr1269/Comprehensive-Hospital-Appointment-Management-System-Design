import React, { useState } from 'react';

function RegisterPatient() {
  return (
    <div>
      <h2>Patient Registration</h2>
      <p>Form for patient name, gender, date of birth, and unique ID.</p>
    </div>
  );
}

export default RegisterPatient;
