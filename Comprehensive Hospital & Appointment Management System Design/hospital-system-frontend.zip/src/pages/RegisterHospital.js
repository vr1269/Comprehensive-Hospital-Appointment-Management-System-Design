import React, { useState } from 'react';
import axios from 'axios';

function RegisterHospital() {
  const [name, setName] = useState('');
  const [location, setLocation] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.post('http://localhost:3000/api/hospitals', { name, location });
    alert('Hospital Registered!');
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Register Hospital</h2>
      <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Hospital Name" required />
      <input value={location} onChange={(e) => setLocation(e.target.value)} placeholder="Location" required />
      <button type="submit">Register</button>
    </form>
  );
}

export default RegisterHospital;
