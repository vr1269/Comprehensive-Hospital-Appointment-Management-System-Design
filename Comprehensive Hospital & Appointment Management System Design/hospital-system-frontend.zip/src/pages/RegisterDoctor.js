import React, { useState } from 'react';

function RegisterDoctor() {
  return (
    <div>
      <h2>Doctor Registration</h2>
      <p>Form for doctor details, specializations, availability, and hospital association.</p>
    </div>
  );
}

export default RegisterDoctor;
